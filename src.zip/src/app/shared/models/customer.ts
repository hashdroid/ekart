import { Address } from "./address";


export class Customer{
    // private String emailId;
	// private String name;
	// private String password;
	// private String phoneNumber;
    // private List<Address> addresses;
    emailId:string;
    name:string;
    password:string;
    phoneNumber:string;
    addresses:Address[];
}