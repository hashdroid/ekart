import { Product } from "./product";

export class RecommendedProduct{
    recommendationId:number;
    productId:Product;
    recommendationTimestamp:Date;
    recommendationStatus:String;
    message:String;
}