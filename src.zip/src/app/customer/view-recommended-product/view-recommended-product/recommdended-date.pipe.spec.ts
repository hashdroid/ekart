import { RecommdendedDatePipe } from './recommdended-date.pipe';

describe('RecommdendedDatePipe', () => {
  it('create an instance', () => {
    const pipe = new RecommdendedDatePipe();
    expect(pipe).toBeTruthy();
  });
});
