import { TestBed, inject } from '@angular/core/testing';

import { ViewRecommendedProductService } from './view-recommended-product.service';

describe('ViewRecommendedProductService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ViewRecommendedProductService]
    });
  });

  it('should be created', inject([ViewRecommendedProductService], (service: ViewRecommendedProductService) => {
    expect(service).toBeTruthy();
  }));
});
