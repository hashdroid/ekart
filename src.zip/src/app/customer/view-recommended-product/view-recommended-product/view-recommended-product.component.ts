import { Component, OnInit } from '@angular/core';
import { ViewRecommendedProductService } from './view-recommended-product.service';
import { Router, ActivatedRoute } from '@angular/router';
//Import { RecommendedProdForCust } from '../../shared/models/recommendedProdForCust';
import { FormBuilder } from '@angular/forms';
import { RecommendedProdForCust } from '../../../shared/models/recommendedProdForCust';

@Component({
  selector: 'app-view-recommended-product',
  templateUrl: './view-recommended-product.component.html',
  styleUrls: ['./view-recommended-product.component.css']
})
export class ViewRecommendedProductComponent implements OnInit {

  constructor(private router: Router, private route: ActivatedRoute,private viewRecommendedProductService:ViewRecommendedProductService,private fb:FormBuilder) { }


  
   recommendedProduct:RecommendedProdForCust[];
   displayOrders:boolean=false;
   errorMessage:string;
  ngOnInit() {
    this.viewRecommendedProductService.getRecommendedProduct()
    .then(response => {
      this.recommendedProduct = response;this.displayOrders = true;
    })
    .catch(
      (error) =>
          this.errorMessage = error._body
      )
  }

}
