import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'recommdendedDate'
})
export class RecommdendedDatePipe implements PipeTransform {

  transform(value: any[], args?: any): any {
    let month:any[]=["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    let day:any=String(value[2]);
    let mon:any=month[parseInt(value[1])];
    let year:any=String(value[0]);
    let HH:any=String(value[3]);
    let MM:any=String(value[4]);
    let SS:any=String(value[5]);




    return mon+" "+day+","+year+"     "+HH+":"+MM+":"+SS;
  
  }

}
