import { OnInit, Component, Input } from "@angular/core";
import { Product } from "../../../shared/models/product";


@Component({
    selector: 'add-to-cart',
    templateUrl: './add-to-cart.component.html'
})
export class AddToCart implements OnInit {
    @Input()
    productToAdd: Product;
    ngOnInit(): void {

    }

}