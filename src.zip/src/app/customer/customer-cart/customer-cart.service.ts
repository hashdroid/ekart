
import { Injectable } from "@angular/core";
import { Http, Headers } from "@angular/http";
import { environment } from "../../../environments/environment";
import { Cart } from "../../shared/models/cart";



@Injectable()
export class CustomerCartService {
    private headers = new Headers({ 'Content-Type': 'text/plain' });
    constructor(private http: Http) { }

    deleteProductFromCart(cart: Cart, customerEmailId: string): Promise<any> {
        let url: string = environment.customerCartUrl + "/deleteProductFromCart/" + customerEmailId;
        return this.http.post(url, cart.cartId, { headers: this.headers })
            .toPromise()
            .then(
            (response) => JSON.parse(JSON.stringify(response))._body
            ).catch(
            this.errorHandeler
            )

    }

    updateCart(cart: Cart): Promise<any> {
        let url: string = environment.customerCartUrl + "/modifyQuantityInCart";
        let headers = new Headers({ 'Content-Type': 'application/json' });
        return this.http.post(url, JSON.stringify(cart), { headers: headers })
            .toPromise()
            .then(
            (response) => JSON.parse(JSON.stringify(response))._body
            ).catch(
            this.errorHandeler
            )

    }



    private errorHandeler(error: any): Promise<any> {
        console.error("Error Occured:\n", error);
        return Promise.reject(error._body);
    }



}