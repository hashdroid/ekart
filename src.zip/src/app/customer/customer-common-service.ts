import { Injectable } from "@angular/core";
import { Product } from "../shared/models/product";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Cart } from "../shared/models/cart";


@Injectable()
export class CustomerSharedService {

    private cartList = new BehaviorSubject<Cart[]>(JSON.parse(sessionStorage.getItem("seller")));
    updatedCartList = this.cartList.asObservable();

    updateCartList(cartList: Cart[]) {
        this.cartList.next(cartList);
    }

}