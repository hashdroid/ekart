import { Injectable } from '@angular/core';

import { Http, Headers } from '@angular/http';
import { environment } from '../../../environments/environment';
import { Product } from '../../shared/models/product';

@Injectable()
export class SellerAddProductService {
  private headers = new Headers({ 'Content-Type': 'application/json' });
  constructor(private http: Http) { }

  addProduct(productToAdd: Product, sellerEmailId): Promise<any> {
    const url = environment.productAPIUrl + '/addProductToSellerCatalog/' + sellerEmailId;
    return this.http.post(url, JSON.stringify(productToAdd), { headers: this.headers })//Line 1      
      .toPromise() //Line 2      
      .then((response) => JSON.parse(JSON.stringify(response))._body) //Line 3      
      .catch(this.errorHandler) //Line 4      
  }


  getProductCategories(): Promise<string[]> {
    const url = environment.productAPIUrl + "/getProductCategories";
    return this.http.get(url)
      .toPromise()
      .then((response) => <string[]>response.json())
      .catch(this.errorHandler)
  }


  private errorHandler(error: any): Promise<any> {
    console.error("Error Occured:\n", error);
    return Promise.reject(JSON.parse(JSON.stringify(error)));
  }
}
