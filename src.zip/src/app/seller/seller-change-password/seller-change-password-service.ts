import { Injectable } from "@angular/core";
import { Http, Headers } from "@angular/http";
import { Seller } from "../../shared/models/seller";
import { environment } from "../../../environments/environment";


@Injectable()
export class SellerChangePasswordService {
  private headers = new Headers({ 'Content-Type': 'application/json' });
  constructor(private http: Http) { }


  updatePassword(seller: Seller): Promise<any> {
    const url = environment.updateSellerAPI + "/changeSellerPassword";
    return this.http.post(url, JSON.stringify(seller), { headers: this.headers }).toPromise()
      .then(
      (response) => JSON.parse(JSON.stringify(response))._body
      ).catch(
      this.errorHandeler
      )

  }
  private errorHandeler(error: any): Promise<any> {
    console.error("Error Occured:\n", error);
    return Promise.reject(JSON.parse(JSON.stringify(error)));
  }
}