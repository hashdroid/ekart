import { Component, OnInit } from '@angular/core';
import { SellerViewRecommendationsService } from './seller-view-recommended-products.service';
import { Router } from '@angular/router';
import { RecommendedProduct } from '../../shared/models/recommendedProduct';

@Component({
  selector: 'app-seller-view-recommended-products',
  templateUrl: './seller-view-recommended-products.component.html',
  styleUrls: ['./seller-view-recommended-products.component.css']
})
export class SellerViewRecommendedProductsComponent implements OnInit {

  constructor(private recommendedProductService: SellerViewRecommendationsService,
  private router: Router) { }

  sellerRecommendedProducts: RecommendedProduct[];
  successMessage:string;
  errorMessage:string;
 
  ngOnInit() {
    this.recommendedProductService.recommendProduct()
    .then(res=>this.sellerRecommendedProducts=res)
    .catch(res=> this.sellerRecommendedProducts=res)
  }

  removeProduct(recommendedProduct:RecommendedProduct,i)
  {
    this.recommendedProductService.removeProduct(recommendedProduct)
    .then(res=>{this.successMessage=res.successMessage,this.ngOnInit()})
    .catch(res=>this.errorMessage=res.errorMessage)
    this.sellerRecommendedProducts.splice(i,i+1);
  }
}

