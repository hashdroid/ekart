import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from '../../../environments/environment';
import 'rxjs/add/operator/toPromise';
import { Seller } from './../../shared/models/seller';
import { SellerLoginComponent } from '../login/seller-login.component';
import { RecommendedProduct } from '../../shared/models/recommendedProduct';

@Injectable()
export class SellerViewRecommendationsService {
  private headers = new Headers({ 'Content-Type': 'application/json' });
  constructor(private http: Http) { }


recommendProduct():Promise<any>
{
    const url = environment.sellerRecommendedProductsAPI + '/view';
    return this.http.post(url,JSON.parse(sessionStorage.getItem("seller")),
    {headers:this.headers})
    .toPromise()
    .then(res=> res.json() as RecommendedProduct[])
    .catch(this.errorHandler);
}

removeProduct(recommendedProduct:RecommendedProduct):Promise<any>
{
    let seller:Seller=(JSON.parse(sessionStorage.getItem("seller")));
    const url = environment.sellerRecommendedProductsAPI + '/remove';
    return this.http.post(url,JSON.stringify(seller.emailId,),
    {headers:this.headers})
    .toPromise()
    .then(res=> res.json() as RecommendedProduct)
    .catch(this.errorHandler);
}


private errorHandler(error: any):Promise<any>
{
    return Promise.reject(error.json() || error);
}
}