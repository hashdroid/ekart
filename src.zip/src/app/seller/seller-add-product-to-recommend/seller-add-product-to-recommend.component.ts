import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-add-product-to-recommend',
  templateUrl: './seller-add-product-to-recommend.component.html',
  styleUrls: ['./seller-add-product-to-recommend.component.css']
})
export class SellerAddProductToRecommendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
