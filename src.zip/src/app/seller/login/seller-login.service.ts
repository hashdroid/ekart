import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { Headers } from '@angular/http';
import { Seller } from './../../shared/models/seller';
import { environment } from '../../../environments/environment';


@Injectable()
export class SellerLoginService {
    private headers = new Headers({ 'Content-Type': 'application/json' });

    constructor(private http: Http) {

    }
    login(seller: Seller): Promise<any> {
        const url = environment.sellerAPIUrl + '/sellerLogin';
        return this.http.post(url, JSON.stringify(seller), { headers: this.headers }).toPromise()
            .then(
            (response) => response.json() as Seller
            ).catch(
            this.errorHandeler
            )

    }

    private errorHandeler(error: any): Promise<any> {
        console.error("Error Occured:\n", error);
        return Promise.reject(error.json() || error);
    }
}