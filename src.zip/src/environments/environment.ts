// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  sellerAPIUrl: 'http://localhost:3333/EKart_Server/SellerAPI',
  updateSellerAPI: 'http://localhost:3333/EKart_Server/UpdateSellerAPI',
  updateCustomerAPI: 'http://localhost:3333/EKart_Server/UpdateCustomerAPI',
  customerAPIUrl: 'http://localhost:3333/EKart_Server/CustomerAPI',
  customerCartUrl: 'http://localhost:3333/EKart_Server/CustomerCartAPI',
  SellerProductManagementAPI: 'http://localhost:3333/EKart_Server/SellerProductManagementAPI',
  sellerOrderAPI: 'http://localhost:3333/EKart_Server/SellerOrderAPI',
  productAPIUrl: 'http://localhost:3333/EKart_Server/SellerProductAPI',
  CustomerProductAPI: 'http://localhost:3333/EKart_Server/CustomerProductAPI',
  sellerRecommendedProductsAPI: 'http://localhost:3333/EKart_Server/SellerRecommendationsAPI',
  viewRecommendedProduct: 'http://localhost:3333/EKart_Server/recommendedProductsAPI/getRecommendation'
}
